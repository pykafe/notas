
# Pandas and matplotlib


```python
import pandas
%matplotlib inline
```


```python
df = pandas.DataFrame({'hello':[121,124,442,33]})
df
```


```python
df.plot(kind='bar')
```


# Countries and population


```python
countries = ['Timor-Leste', 'Portugal', 'UK', 'USA']
populations = [1296311,10329506,263991379,66181585]
area = [14874, 88267, 243610, 9525067]
gdp = [2498, 204761, 2629188, 18569100]
columns = {'Countries': countries, 'Populations': populations, 'GDP': gdp}
data_frame = pandas.DataFrame(columns, index=countries)
data_frame
```


```python
data_frame.plot(kind='bar')
```

```python
import pandas
%matplotlib inline

population_scale = 10
countries = ['Timor-Leste', 'Portugal', 'Indonesia', 'UK', 'US']
populations =  [1296311, 10329506, 263991379, 66181585, 324459463]
scaled_populations = [p / population_scale for p in populations]
area =  [14874, 88267, 1919440, 244820, 9525067]
gdp = [2498, 204761, 932448, 2629188, 18569100]
stats = {
    'Population ( 100 )': scaled_populations,
    'Area ( square km )': area,
    'GDP ( million USD )': gdp,
}
country_data = pandas.DataFrame(stats, index=countries)

# country_data.plot(kind='bar')
country_data.plot.pie(subplots=True, figsize=(21, 7))
```

